'use strict';

/**
 * @ngdoc function
 * @name farmersmarketApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the farmersmarketApp
 */
angular.module('farmersmarketApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
